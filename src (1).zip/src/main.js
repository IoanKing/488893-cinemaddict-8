import Selector from "./selectors";
import FilmList from "./film-list";
import FilterList from "./filter-list";

const DEFAULT_EXTRA_COUNT = 2;
const MAX_MOVIE_COUNT = 15;

const navigation = document.querySelector(`.${Selector.NAVIGATION}`);
const filmContainer = document.querySelector(`.${Selector.CONTAINER}`);
const topFilmContainer = document.querySelector(`#${Selector.TOP_MOVIE}`);
const commentedFilmContainer = document.querySelector(`#${Selector.COMMENTED_MOVIE}`);

const filterDefault = (collection) => {
  return Object.values(collection);
};

const filterTopRated = (collection) => {
  return Object.values(collection).sort((a, b) => b._rating - a._rating).slice(0, DEFAULT_EXTRA_COUNT);
};

const filterTopComment = (collection) => {
  return Object.values(collection).sort((a, b) => b._comments.length - a._comments.length).slice(0, DEFAULT_EXTRA_COUNT);
};

const filterFavorites = (collection) => {
  return Object.values(collection).filter((it) => it._isFavorite);
};

const filterWathlists = (collection) => {
  return Object.values(collection).filter((it) => it._isWatchList);
};

/**
 * Инициализация скриптов для сайта.
 *  Запускает фнукцию отрисовки фильтров;
 *  Запускает функцию генерации случайной коллекции задач;
 *  Запускает функцию орисовки карточек задач;
 *  Запускает обработкик обработки клика на фильтр.
 */
const init = () => {
  const filmList = new FilmList();
  const filterList = new FilterList();
  filterList.onFilmList = filmList;
  filterList.render(navigation);

  filmList.defaultContainer = filmContainer;

  filmList.Filter = filterDefault;
  filmList.render();

  filmList.Filter = filterTopRated;
  filmList.render(topFilmContainer, false);

  filmList.Filter = filterTopComment;
  filmList.render(commentedFilmContainer, false);
};

init();
