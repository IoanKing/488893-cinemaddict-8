export default {
  NAVIGATION: `main-navigation`,
  NAVIGATION_ITEM: `main-navigation__item`,
  FILM_LIST: `films-list`,
  CONTAINER: `films-list__container`,
  ALL_MOVIE: `all-movie`,
  TOP_MOVIE: `top-movie`,
  COMMENTED_MOVIE: `commented-movie`,
};
