import Film from "./film";
import {mockdata} from "./mock";

export default class FilmList {
  constructor() {
    this._collection = this._getCollection(mockdata.slice(0, Math.min(20, mockdata.length)));
    this._defaultContainer = null;
    this._onFilterData = Object.values(this._collection);
  }

  _makeFilm(element) {
    const newFilm = new Film(element);
    return newFilm;
  }

  _getCollection(collection) {
    const Films = [];
    collection.forEach((element) => {
      Films.push(this._makeFilm(element));
    });
    return Films;
  }

  set Filter(fn) {
    this._onFilter = fn;
  }

  set defaultContainer(obj) {
    this._defaultContainer = obj;
  }

  get collection() {
    return this._collection;
  }

  render(container = this._defaultContainer, isControls = true) {
    container.innerHTML = ``;
    const partOfElements = this._onFilter(this._onFilterData);

    const fragment = document.createDocumentFragment();
    partOfElements.forEach((it) => {
      fragment.appendChild(it.render(isControls));
    });
    container.appendChild(fragment);
  }

  unrender() {
    this._onFilterData = Object.values(this._collection);
  }

  update(collection) {
    this.unrender();
    this._onFilterData = collection;
    this.render();
  }
}
